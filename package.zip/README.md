# ads-copy-generator
This browser extension allows you to create contextual texts for your ads
